var fetch = global.nodemodule["node-fetch"];

var covid_get = function covid_get(type, data) {
	(async function () {
		var fetchdata = await fetch("https://code.junookyo.xyz/api/ncov-moh/data.json");
		var jsondatax = await fetchdata.json();
		var jsondata = jsondatax.data || {};
		var vn = jsondata.vietnam || {};
		var global = jsondata.global || {};
		var returntext = `Số ca bình phục/tử vong/nhiễm COVID-19 (K/D/A): \r\n- Việt Nam: ${vn.recovered}/${vn.deaths}/${vn.cases}\r\n- Thế giới: ${global.recovered}/${global.deaths}/${global.cases}\n+ Trước tình hình diễn biến phức tạp của covid 19\n+ Mọi người dân phải có ý thực "Phòng bệnh hơn chữa bệnh"\n+ Hãy ở nhà vì sức khẻo cộng đồng\n+ Hạn chế tiếp súc gần với người bệnh hoặc ra những nơi đông người\n+ Nếu có triệu trứng sốt , ho , khó thở , hãy đến ngay trung tâm y tế gần nhất để được khám và chữa bệnh kịp thời\n+ Chúc bạn có một kỉ nghỉ dịch an toàn bên gia đình ^^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	covid_get: covid_get
}